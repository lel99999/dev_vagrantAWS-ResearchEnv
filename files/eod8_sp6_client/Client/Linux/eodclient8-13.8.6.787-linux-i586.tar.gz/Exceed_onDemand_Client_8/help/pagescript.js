if (top == self)
{
	var thisdoc = document.location.href.substring(location.href.lastIndexOf("/")+1);
	top.location.replace("ExceedonDemand_frames.html?"+thisdoc);
}

function toggleInline(section)
{
	var curImg = document.images[section + "_img"].src;
	curImg = curImg.slice(curImg.lastIndexOf("/") + 1);
	if (curImg == "inline_closed.gif")
	{
		document.images[section + "_img"].src = "images/inline_open.gif";
		document.images[section + "_img"].alt = "Collapse";
		document.all[section].style.display = "block";
	}
	else
	{
		document.images[section + "_img"].src = "images/inline_closed.gif";
		document.images[section + "_img"].alt = "Expand";
		document.all[section].style.display = "none";
	}
	return;
}